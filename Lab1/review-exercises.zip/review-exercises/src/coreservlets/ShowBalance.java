package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ShowBalance extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
    String id = request.getParameter("customerID");
    if ((id == null) || (id.trim().equals(""))) {
      id = "<i>missing-id</i>";
    }
    Customer customer = CustomerUtils.getCustomer(id);
    String address;
    if (customer == null) {
      request.setAttribute("id", id);
      address = "/WEB-INF/results/unknown-customer.jsp";
    } else {
      request.setAttribute("customer", customer);
      address = "/WEB-INF/results/show-balance.jsp";
    }
    RequestDispatcher dispatcher =
      request.getRequestDispatcher(address);
    dispatcher.forward(request, response);
  }
}
